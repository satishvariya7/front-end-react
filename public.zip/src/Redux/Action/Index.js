export function setData(payload) {   
  return {
    type: "SET_DATA",
    payload: payload,
  };
}
